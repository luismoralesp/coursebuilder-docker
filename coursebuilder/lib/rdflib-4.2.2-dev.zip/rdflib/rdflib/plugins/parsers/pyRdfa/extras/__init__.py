"""
Collection of external modules that are used by pyRdfa and are added for an easier 
distribution
"""
